import { Component, OnInit } from '@angular/core';
import {ListboxModule} from 'primeng/listbox';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  public search:any = '';
  dataList: any[] = [];
  bool: true;
  fieldList: any[] = [
    {name: 'First Name'},
    {name: 'Last Name'},
    {name: 'Company'},
    {name: 'Email'},
    {name: 'City'}
  ];
    selectedfieldList: any;
    passValue1='';
    selectedDataList = [];

  constructor(){}

  ngOnInit(){
      this.dataList = [
        {fname: 'James', lname: 'Joseph', company: 'Microsoft', email: 'james.j@microsoft.com', city: 'New York'},
        {fname: 'Rutvik', lname: 'Patel', company: 'TCS', email: 'rutvik.p@tcs.com', city: 'Gandhinagar'},
        {fname: 'Lara', lname: 'Anderson', company: 'Google', email: 'lara.a@google.com', city: 'Chicago'},
        {fname: 'Samarth', lname: 'Ramaswamy', company: 'Adobe', email: 'samarth.r@adobe.com', city: 'Bangaluru'},
        {fname: 'Andrew', lname: 'Smith', company: 'Accenture', email: 'andrew.s@accenture.com', city: 'London'},
        {fname: 'James', lname: 'Peter', company: 'Congnizant', email: 'james.p@congizant.com', city: 'London'}
      ]
  }

  fieldCheck(){
    this.bool != this.bool;
  }

  dummyCheck(){
    console.log(this.selectedfieldList);
    if(this.selectedfieldList.name == 'First Name'){
      console.log(this.selectedfieldList.name);
      this.passValue1 = 'fname'
    }else if(this.selectedfieldList.name == 'Last Name'){
      this.passValue1 = 'lname'
    }
  }

  dummyCheck2(){
    console.log(this.selectedDataList);
  }

}
